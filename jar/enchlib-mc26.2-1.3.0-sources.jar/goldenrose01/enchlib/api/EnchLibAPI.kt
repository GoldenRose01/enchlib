package goldenrose01.enchlib.api

import goldenrose01.enchlib.config.GlobalConfigIO
import goldenrose01.enchlib.config.MobCategoryManager
import goldenrose01.enchlib.utils.EnchLogger
import net.minecraft.server.MinecraftServer
import net.minecraft.world.entity.Entity
import java.util.TreeMap

/**
 * EnchantLibAPI
 *
 * API minimale e stabile per accedere/modificare la configurazione **globale**
 * (cartella: ~/.minecraft/config/enchlib).
 *
 * - getEnabledEnchantments(): List<String>
 * - isEnabled(id): Boolean
 * - getMaxLevel(id): Int?
 * - setEnabled(id, enabled)
 * - setMaxLevel(id, level)   (level >= 1)
 * - save()                    (flush esplicito opzionale)
 *
 * Nota: le funzioni scrivono subito su disco per semplicità e atomicità.
 */
object EnchantLibAPI {

    /** Checks whether an entity has a world-configured mob category. */
    @JvmStatic
    fun hasMobCategory(server: MinecraftServer, entity: Entity, category: String): Boolean =
        MobCategoryManager.hasCategory(server, entity, category)

    /**
     * Importa in batch i metadati predefiniti forniti da un'altra mod.
     * Gli ID devono essere completi (namespace:path). Le voci già configurate
     * mantengono abilitazione, livello massimo e categorie scelti dall'utente.
     */
    @JvmStatic
    fun registerEnchantments(maxLevels: Map<String, Int>, enchantmentCategories: Map<String, List<String>>): Int =
        registerEnchantments(maxLevels, enchantmentCategories, emptyMap())

    /** Imports item compatibility and target mob categories for a batch of enchantments. */
    @JvmStatic
    fun registerEnchantments(
        maxLevels: Map<String, Int>,
        enchantmentCategories: Map<String, List<String>>,
        mobCategories: Map<String, List<String>>
    ): Int {
        if (maxLevels.isEmpty()) return 0

        val available = GlobalConfigIO.readAvailable().toMutableList()
        val details = GlobalConfigIO.readDetails()
        val availableIds = available.map { it.id }.toMutableSet()
        val detailsById = details.enchantments.associateBy { it.id }
        var registered = 0

        for ((id, maxLevel) in TreeMap(maxLevels)) {
            if (!id.matches(Regex("^[a-z0-9_.-]+:[a-z0-9_./-]+$"))) {
                EnchLogger.warn("API: ignorato ID incantesimo non valido: $id")
                continue
            }

            if (availableIds.add(id)) {
                // Nuova voce visibile per impostazione predefinita; le scelte esistenti restano intatte.
                available += GlobalConfigIO.AvailableEnch(id = id, enabled = true)
            }

            val categories = enchantmentCategories[id].orEmpty().distinct().sorted().toMutableList()
            val targets = mobCategories[id].orEmpty().distinct().sorted().toMutableList()
            val existing = detailsById[id]
            if (existing == null) {
                details.enchantments += GlobalConfigIO.EnchantmentDetails(
                    id = id,
                    max_level = maxLevel.coerceAtLeast(1),
                    enc_category = categories,
                    mob_category = targets
                )
            } else {
                if (existing.enc_category.isEmpty() && categories.isNotEmpty()) {
                    existing.enc_category = categories
                }
                if (existing.mob_category.isEmpty() && targets.isNotEmpty()) {
                    existing.mob_category = targets
                }
            }
            registered++
        }

        available.sortBy { it.id }
        details.enchantments.sortBy { it.id }
        GlobalConfigIO.writeAvailable(available)
        GlobalConfigIO.writeDetails(details)
        EnchLogger.info("API: sincronizzati $registered incantesimi registrati dalle mod dipendenti.")
        return registered
    }

    /** Ritorna gli ID abilitati (ordinati). */
    fun getEnabledEnchantments(): List<String> =
        GlobalConfigIO.readAvailable()
            .filter { it.enabled }
            .map { it.id }
            .sorted()

    /** true se l'id è presente e abilitato. */
    fun isEnabled(id: String): Boolean =
        GlobalConfigIO.readAvailable().any { it.id == id && it.enabled }

    /** Max level configurato per l'id, se presente. */
    fun getMaxLevel(id: String): Int? =
        GlobalConfigIO.readDetails()
            .enchantments
            .firstOrNull { it.id == id }
            ?.max_level

    /** Abilita/disabilita un incantesimo in AviableEnch.json5 (upsert). */
    fun setEnabled(id: String, enabled: Boolean) {
        val list = GlobalConfigIO.readAvailable().toMutableList()
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = GlobalConfigIO.AvailableEnch(id, enabled)
        else list += GlobalConfigIO.AvailableEnch(id, enabled)
        list.sortBy { it.id }
        GlobalConfigIO.writeAvailable(list)
        EnchLogger.info("EnchantLibAPI: setEnabled($id, $enabled)")
    }

    /** Imposta il max level (>=1) in EnchantmentsDetails.json5 (upsert). */
    fun setMaxLevel(id: String, level: Int) {
        val lvl = level.coerceAtLeast(1)
        val root = GlobalConfigIO.readDetails()
        val list = root.enchantments
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i].max_level = lvl
        else list += GlobalConfigIO.EnchantmentDetails(id = id, max_level = lvl)
        list.sortBy { it.id }
        GlobalConfigIO.writeDetails(root)
        EnchLogger.info("EnchantLibAPI: setMaxLevel($id, $lvl)")
    }

    /** Scrive eventuali buffer (qui i metodi scrivono già; funzione lasciata per simmetria). */
    fun save() {
        // No-op: l’API scrive immediatamente
    }
}
