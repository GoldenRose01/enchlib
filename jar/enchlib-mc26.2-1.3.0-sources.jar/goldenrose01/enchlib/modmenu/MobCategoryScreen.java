package goldenrose01.enchlib.modmenu;

import dev.isxander.yacl3.api.ConfigCategory;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.api.YetAnotherConfigLib;
import dev.isxander.yacl3.api.controller.StringControllerBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import goldenrose01.enchlib.config.MobCategoryManager;

import java.util.List;
import java.util.regex.Pattern;

/** Small in-game editor; changes are applied to the active world immediately. */
public final class MobCategoryScreen {
    private static final Pattern ENTITY_ID = Pattern.compile("^[a-z0-9_.-]+:[a-z0-9/._-]+$");
    private static final Pattern CATEGORY_LIST = Pattern.compile("^[a-zA-Z0-9_.:, -]*$");

    private MobCategoryScreen() { }

    public static Screen create(Screen parent) {
        Minecraft client = Minecraft.getInstance();
        String[] entityId = {targetEntityId(client)};
        String[] categoryCsv = {MobCategoryManager.INSTANCE.getCategories(entityId[0]).stream()
                .reduce((left, right) -> left + "," + right).orElse("")};

        Option<String> entityOption = Option.<String>createBuilder()
                .name(Component.literal("Entity registry ID"))
                .description(OptionDescription.of(Component.literal(
                        "Use a namespaced ID such as minecraft:zombie or othermod:crystal_beast.")))
                .binding(entityId[0], () -> entityId[0], value -> entityId[0] = value.trim())
                .controller(StringControllerBuilder::create)
                .build();

        Option<String> categoriesOption = Option.<String>createBuilder()
                .name(Component.literal("Categories (comma separated)"))
                .description(OptionDescription.of(Component.literal(
                        "Example: undead,hostile. Enter none to remove all categories.")))
                .binding(categoryCsv[0], () -> categoryCsv[0], value -> categoryCsv[0] = value.trim())
                .controller(StringControllerBuilder::create)
                .build();

        ConfigCategory category = ConfigCategory.createBuilder()
                .name(Component.literal("Mob categories"))
                .option(entityOption)
                .option(categoriesOption)
                .build();

        return YetAnotherConfigLib.createBuilder()
                .title(Component.literal("EnchLib — Mob categories"))
                .category(category)
                .save(() -> apply(client, entityId[0], categoryCsv[0]))
                .build()
                .generateScreen(parent);
    }

    private static String targetEntityId(Minecraft client) {
        HitResult hit = client.hitResult;
        if (hit instanceof EntityHitResult entityHit) {
            Entity entity = entityHit.getEntity();
            return BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
        }
        return "minecraft:zombie";
    }

    private static void apply(Minecraft client, String rawId, String rawCategories) {
        String id = rawId.trim();
        String categories = rawCategories.trim();
        if (!ENTITY_ID.matcher(id).matches() || !(categories.equalsIgnoreCase("none") || CATEGORY_LIST.matcher(categories).matches())) {
            return;
        }
        List<String> parsedCategories = categories.equalsIgnoreCase("none") || categories.isBlank()
                ? List.of()
                : java.util.Arrays.stream(categories.split(","))
                    .map(String::trim).filter(value -> !value.isEmpty()).toList();

        if (client.getSingleplayerServer() != null) {
            client.getSingleplayerServer().execute(() -> {
                try {
                    MobCategoryManager.INSTANCE.setCategories(client.getSingleplayerServer(), id, parsedCategories);
                } catch (Exception exception) {
                    goldenrose01.enchlib.utils.EnchLogger.INSTANCE.error("Impossibile salvare categorie mob da YACL", exception);
                }
            });
        } else if (client.player != null) {
            String commandCategories = parsedCategories.isEmpty() ? "none" : String.join(",", parsedCategories);
            client.player.connection.sendCommand("plusec-debug mob set " + id + " " + commandCategories);
        }
    }

}
