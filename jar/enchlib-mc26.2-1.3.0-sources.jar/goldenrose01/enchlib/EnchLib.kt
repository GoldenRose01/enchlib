package goldenrose01.enchlib

import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback

import net.minecraft.commands.CommandSourceStack

import com.mojang.brigadier.CommandDispatcher

import goldenrose01.enchlib.commands.DebugCommands
import goldenrose01.enchlib.commands.EnchLibCommands
import goldenrose01.enchlib.config.GlobalConfigBootstrap
import goldenrose01.enchlib.config.MobCategoryManager

import org.slf4j.LoggerFactory

object Enchlib : ModInitializer {
    const val MOD_ID = "enchlib"
    private val LOGGER = LoggerFactory.getLogger(MOD_ID)

    override fun onInitialize() {
        LOGGER.info("[$MOD_ID] Initializing...")

        // World configuration
        GlobalConfigBootstrap.ensureDefaultsInstalled()
        MobCategoryManager.registerHooks()

        // Registrazione comandi (Fabric API v2)
        CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
            EnchLibCommands.register(dispatcher)
            DebugCommands.register(dispatcher)
        }
    }
}
